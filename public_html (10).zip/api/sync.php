<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/conexion.php';

$metodo = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = obtenerPDO();

    // Asegurar tabla movimientos_stock para trazabilidad de ventas
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `movimientos_stock` (
            `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `producto_id` INT(11) NOT NULL,
            `sucursal_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT 1,
            `tipo` VARCHAR(50) NOT NULL DEFAULT 'VENTA',
            `cantidad` DECIMAL(12,2) NOT NULL,
            `saldo_anterior` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `saldo_posterior` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `motivo` VARCHAR(255) NULL DEFAULT NULL,
            `referencia_id` VARCHAR(100) NULL DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $eTable) {
        // Ignorar si no hay permisos de DDL
    }

    if ($metodo === 'GET') {
        // Consultar movimientos de stock para auditoria en tiempo real en ERP
        if (isset($_GET['movimientos'])) {
            try {
                $stmt = $pdo->query("SELECT m.*, p.codigo, p.descripcion, COALESCE(s.nombre, CONCAT('Sucursal ', m.sucursal_id)) AS sucursal_nombre
                                      FROM movimientos_stock m
                                      LEFT JOIN productos p ON m.producto_id = p.id
                                      LEFT JOIN sucursales s ON m.sucursal_id = s.id
                                      ORDER BY m.created_at DESC LIMIT 100");
                echo json_encode(['status' => 'ok', 'movimientos' => $stmt->fetchAll()]);
                exit;
            } catch (Throwable $eMovs) {
                echo json_encode(['status' => 'ok', 'movimientos' => []]);
                exit;
            }
        }
        $sku = $_GET['sku'] ?? $_GET['codigo'] ?? null;
        $sucursalId = (int)($_GET['sucursal_id'] ?? 1);

        if ($sku) {
            $stmt = $pdo->prepare("SELECT 
                                    p.id, 
                                    p.codigo, 
                                    p.codigo AS sku, 
                                    p.descripcion, 
                                    p.descripcion AS nombre, 
                                    p.precio_final AS Venta, 
                                    p.precio_final AS precio_base, 
                                    COALESCE(i.cantidad, p.stock_actual, 0) AS stock 
                                   FROM productos p 
                                   LEFT JOIN inventarios i ON p.id = i.producto_id AND i.sucursal_id = ?
                                   WHERE (p.codigo = ? OR p.codigo_barra = ?) 
                                   LIMIT 1");
            $stmt->execute([$sucursalId, $sku, $sku]);
            $res = $stmt->fetch();
            if (!$res) {
                http_response_code(404);
                echo json_encode(['status' => 'error', 'mensaje' => 'Producto no encontrado']);
                exit;
            }
            echo json_encode(['status' => 'ok', 'producto' => $res]);
            exit;
        } else {
            $stmt = $pdo->prepare("SELECT 
                                    p.id, 
                                    p.codigo, 
                                    p.codigo AS sku, 
                                    p.descripcion, 
                                    p.descripcion AS nombre, 
                                    p.precio_final AS Venta, 
                                    p.precio_final AS precio_base, 
                                    COALESCE(i.cantidad, p.stock_actual, 0) AS stock 
                                   FROM productos p 
                                   LEFT JOIN inventarios i ON p.id = i.producto_id AND i.sucursal_id = ?
                                   WHERE p.activo = 1
                                   ORDER BY p.rubro ASC, p.descripcion ASC");
            $stmt->execute([$sucursalId]);
            echo json_encode(['status' => 'ok', 'articulos' => $stmt->fetchAll()]);
            exit;
        }
    }

    if ($metodo === 'POST') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        // Soporte para transferencia de stock entre Local Ramos Mejia y Local Haedo
        if (($data['accion'] ?? '') === 'TRANSFERENCIA') {
            $codigo = trim((string)($data['codigo'] ?? ''));
            $cantTransferir = (float)($data['cantidad'] ?? 0);
            $sucOrigen = (int)($data['sucursal_origen'] ?? 1);
            $sucDestino = (int)($data['sucursal_destino'] ?? 2);

            if ($codigo === '' || $cantTransferir <= 0 || $sucOrigen === $sucDestino) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'mensaje' => 'Parametros de transferencia invalidos.']);
                exit;
            }

            $pdo->beginTransaction();
            $stmtP = $pdo->prepare("SELECT id, codigo, descripcion FROM productos WHERE codigo = ? LIMIT 1 FOR UPDATE");
            $stmtP->execute([$codigo]);
            $prod = $stmtP->fetch();

            if (!$prod) {
                $pdo->rollBack();
                http_response_code(404);
                echo json_encode(['status' => 'error', 'mensaje' => 'Producto no encontrado']);
                exit;
            }

            $stmtOrig = $pdo->prepare("SELECT cantidad FROM inventarios WHERE producto_id = ? AND sucursal_id = ? FOR UPDATE");
            $stmtOrig->execute([$prod['id'], $sucOrigen]);
            $stkOrig = (float)($stmtOrig->fetchColumn() ?: 0);

            if ($stkOrig < $cantTransferir) {
                $pdo->rollBack();
                http_response_code(409);
                echo json_encode(['status' => 'error', 'mensaje' => "Stock insuficiente en sucursal origen. Disponible: $stkOrig, a transferir: $cantTransferir"]);
                exit;
            }

            // Descontar origen
            $stmtUpdOrig = $pdo->prepare("INSERT INTO inventarios (producto_id, sucursal_id, cantidad, ubicacion)
                                         VALUES (?, ?, ?, 'MOSTRADOR')
                                         ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
            $stmtUpdOrig->execute([$prod['id'], $sucOrigen, $stkOrig - $cantTransferir]);

            // Sumar destino
            $stmtDest = $pdo->prepare("SELECT cantidad FROM inventarios WHERE producto_id = ? AND sucursal_id = ? FOR UPDATE");
            $stmtDest->execute([$prod['id'], $sucDestino]);
            $stkDest = (float)($stmtDest->fetchColumn() ?: 0);

            $stmtUpdDest = $pdo->prepare("INSERT INTO inventarios (producto_id, sucursal_id, cantidad, ubicacion)
                                         VALUES (?, ?, ?, 'MOSTRADOR')
                                         ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
            $stmtUpdDest->execute([$prod['id'], $sucDestino, $stkDest + $cantTransferir]);

            // Auditoria
            $refId = 'TRANS-' . time();
            $stmtAudit = $pdo->prepare("INSERT INTO movimientos_stock (producto_id, sucursal_id, tipo, cantidad, saldo_anterior, saldo_posterior, motivo, referencia_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmtAudit->execute([$prod['id'], $sucOrigen, 'TRANSFERENCIA_SALIDA', -$cantTransferir, $stkOrig, $stkOrig - $cantTransferir, "Envio a Sucursal $sucDestino", $refId]);
            $stmtAudit->execute([$prod['id'], $sucDestino, 'TRANSFERENCIA_ENTRADA', $cantTransferir, $stkDest, $stkDest + $cantTransferir, "Recepcion de Sucursal $sucOrigen", $refId]);

            $pdo->commit();
            echo json_encode(['status' => 'ok', 'mensaje' => "Transferencia de $cantTransferir unidades completada con exito."]);
            exit;
        }

        if (!$data || !isset($data['items']) || !is_array($data['items'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'Datos invalidos. Se requiere array de items.']);
            exit;
        }

        $canal = $data['canal'] ?? 'VENTA_LOCAL';
        $sucursalId = (int)($data['sucursal_id'] ?? 1);
        $referenciaId = $data['referencia_id'] ?? ('ORD-' . time());

        $pdo->beginTransaction();
        $detallesProcesados = [];

        foreach ($data['items'] as $item) {
            $codigo = trim((string)($item['codigo'] ?? $item['sku'] ?? ''));
            $cantDebitar = (float)($item['cantidad'] ?? 1);

            if ($codigo === '' || $cantDebitar <= 0) {
                continue;
            }

            // SELECT ... FOR UPDATE (Bloqueo Pesimista en la base de datos)
            $stmtLock = $pdo->prepare("SELECT 
                                        p.id, 
                                        p.codigo, 
                                        p.descripcion AS nombre, 
                                        COALESCE(i.cantidad, p.stock_actual, 0) AS stock_actual 
                                       FROM productos p 
                                       LEFT JOIN inventarios i ON p.id = i.producto_id AND i.sucursal_id = ?
                                       WHERE (p.codigo = ? OR p.codigo_barra = ?) 
                                       LIMIT 1 
                                       FOR UPDATE");
            $stmtLock->execute([$sucursalId, $codigo, $codigo]);
            $prod = $stmtLock->fetch();

            if (!$prod) {
                $pdo->rollBack();
                http_response_code(400);
                echo json_encode(['status' => 'error', 'mensaje' => "El código o SKU '$codigo' no existe en inventario."]);
                exit;
            }

            $stockActual = (float)$prod['stock_actual'];
            if ($stockActual < $cantDebitar) {
                $pdo->rollBack();
                http_response_code(409);
                echo json_encode([
                    'status' => 'error', 
                    'mensaje' => "Stock insuficiente para '{$prod['nombre']}'. Disponible: $stockActual, Solicitado: $cantDebitar"
                ]);
                exit;
            }

            $stockPosterior = $stockActual - $cantDebitar;

            // Actualizar inventarios por sucursal
            $stmtUpdInv = $pdo->prepare("INSERT INTO inventarios (producto_id, sucursal_id, cantidad, ubicacion)
                                         VALUES (?, ?, ?, 'MOSTRADOR')
                                         ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
            $stmtUpdInv->execute([$prod['id'], $sucursalId, $stockPosterior]);

            // Actualizar stock general en productos
            $stmtUpdProd = $pdo->prepare("UPDATE productos SET stock_actual = ? WHERE id = ?");
            $stmtUpdProd->execute([$stockPosterior, $prod['id']]);

            // Registrar en auditoría de movimientos si existe la tabla
            try {
                $stmtMov = $pdo->prepare("INSERT INTO movimientos_stock 
                    (producto_id, sucursal_id, tipo, cantidad, saldo_anterior, saldo_posterior, motivo, referencia_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmtMov->execute([
                    $prod['id'],
                    $sucursalId,
                    $canal,
                    -$cantDebitar,
                    $stockActual,
                    $stockPosterior,
                    "Venta por canal $canal",
                    $referenciaId
                ]);
            } catch (Throwable $eMov) {
                error_log("Aviso auditoria stock: " . $eMov->getMessage());
            }

            $detallesProcesados[] = [
                'codigo' => $prod['codigo'],
                'nombre' => $prod['nombre'],
                'cantidad' => $cantDebitar,
                'stock_restante' => $stockPosterior
            ];
        }

        // Mantener archivo productos.json en disco sincronizado en tiempo real
        try {
            $jsonPath = dirname(__DIR__) . '/productos.json';
            if (file_exists($jsonPath) && is_writable($jsonPath)) {
                $jsonContent = file_get_contents($jsonPath);
                $jsonProds = json_decode($jsonContent, true);
                if (is_array($jsonProds)) {
                    $modificado = false;
                    foreach ($detallesProcesados as $dp) {
                        foreach ($jsonProds as &$jp) {
                            if (($jp['Codigo'] ?? '') === $dp['codigo'] || ($jp['codigo'] ?? '') === $dp['codigo']) {
                                $jp['Stock'] = (int)$dp['stock_restante'];
                                $jp['stock_actual'] = (int)$dp['stock_restante'];
                                $modificado = true;
                                break;
                            }
                        }
                    }
                    if ($modificado) {
                        file_put_contents($jsonPath, json_encode($jsonProds, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
                    }
                }
            }
        } catch (Throwable $eJson) {
            error_log("Aviso actualizacion productos.json: " . $eJson->getMessage());
        }

        $pdo->commit();

        echo json_encode([
            'status' => 'ok',
            'mensaje' => 'Stock actualizado exitosamente con bloqueo pesimista.',
            'referencia_id' => $referenciaId,
            'items_procesados' => $detallesProcesados
        ]);
        exit;
    }

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => $e->getMessage()]);
}