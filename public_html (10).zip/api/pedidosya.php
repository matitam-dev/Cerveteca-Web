<?php
declare(strict_types=1);

/**
 * ==============================================================================
 * HERMOSOS PERDEDORES CERVETECA - INTEGRACIÓN API PEDIDOSYA
 * ==============================================================================
 * Conexión oficial de Delivery Hero / PedidosYa Orders & Catalog API.
 * 
 * URL Oficial de la Tienda:
 * https://www.pedidosya.com.ar/restaurantes/la-matanza/ph-cervezas-heladas-8d632941-4f25-48cf-853f-f1675c29009a-menu
 * 
 * Funcionalidades:
 * 1. Webhook receptor de órdenes entrantes de PedidosYa en tiempo real.
 * 2. Mapeo automático de sucursal (Ramos Mejía vs Haedo).
 * 3. Descuento automático de stock en MariaDB e inventario físico de la sede.
 * 4. Registro de orden para preparación en mostrador y despacho a repartidor (rider).
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-PedidosYa-Signature');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/conexion.php';

$metodo = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = obtenerPDO();

    if ($metodo === 'GET') {
        // Consultar estado de integración y últimas órdenes de PedidosYa
        $stmt = $pdo->query("SELECT * FROM pedidos WHERE canal LIKE '%PEDIDOSYA%' ORDER BY created_at DESC LIMIT 20");
        $ordenesPeya = $stmt->fetchAll();

        echo json_encode([
            'status' => 'ok',
            'servicio' => 'PedidosYa Integration Engine',
            'tienda_url' => 'https://www.pedidosya.com.ar/restaurantes/la-matanza/ph-cervezas-heladas-8d632941-4f25-48cf-853f-f1675c29009a-menu',
            'sucursal_1_ramos' => 'Av. de Mayo 340, Ramos Mejía',
            'sucursal_2_haedo' => 'Av. Rivadavia 16100, Haedo',
            'ordenes_recientes' => $ordenesPeya,
            'api_config' => [
                'webhook_url_ramos' => 'https://perdedoreshermosos.com.ar/api/pedidosya.php?sucursal_id=1',
                'webhook_url_haedo' => 'https://perdedoreshermosos.com.ar/api/pedidosya.php?sucursal_id=2',
                'habilitado' => defined('PEYA_HABILITADO') ? PEYA_HABILITADO : true
            ]
        ]);
        exit;
    }

    if ($metodo === 'POST') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'Payload JSON de PedidosYa requerido.']);
            exit;
        }

        // Determinar sucursal
        $sucursalId = (int)($_GET['sucursal_id'] ?? $data['sucursal_id'] ?? 1);
        $orderId = trim((string)($data['order_id'] ?? $data['id'] ?? ('PEYA-' . time())));
        $clienteNombre = trim((string)($data['customer']['name'] ?? $data['cliente_nombre'] ?? 'Cliente PedidosYa'));
        $clienteTel = trim((string)($data['customer']['phone'] ?? ''));
        $direccion = trim((string)($data['delivery']['address'] ?? 'Envío PedidosYa'));
        $total = (float)($data['total'] ?? $data['order_total'] ?? 0);
        $items = $data['items'] ?? $data['products'] ?? [];

        $pdo->beginTransaction();

        $detallesProcesados = [];

        foreach ($items as $it) {
            $sku = trim((string)($it['sku'] ?? $it['codigo'] ?? ''));
            $nombre = trim((string)($it['name'] ?? $it['descripcion'] ?? ''));
            $cant = (float)($it['quantity'] ?? $it['cantidad'] ?? 1);

            if ($cant <= 0) continue;

            // Bloqueo pesimista para descontar stock exacto
            $stmtP = $pdo->prepare("SELECT p.id, p.codigo, p.descripcion, COALESCE(i.cantidad, p.stock_actual, 0) AS stock_actual 
                                    FROM productos p 
                                    LEFT JOIN inventarios i ON p.id = i.producto_id AND i.sucursal_id = ?
                                    WHERE (p.codigo = ? OR p.descripcion LIKE ?) 
                                    LIMIT 1 FOR UPDATE");
            $stmtP->execute([$sucursalId, $sku, "%$nombre%"]);
            $prod = $stmtP->fetch();

            if ($prod) {
                $stockAnt = (float)$prod['stock_actual'];
                $stockPost = max(0, $stockAnt - $cant);

                // Descontar inventarios
                $stmtInv = $pdo->prepare("INSERT INTO inventarios (producto_id, sucursal_id, cantidad, ubicacion)
                                           VALUES (?, ?, ?, 'MOSTRADOR')
                                           ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
                $stmtInv->execute([$prod['id'], $sucursalId, $stockPost]);

                // Actualizar tabla productos
                $stmtUpProd = $pdo->prepare("UPDATE productos SET stock_actual = ? WHERE id = ?");
                $stmtUpProd->execute([$stockPost, $prod['id']]);

                // Registrar en auditoría
                $stmtMov = $pdo->prepare("INSERT INTO movimientos_stock 
                    (producto_id, sucursal_id, tipo, cantidad, saldo_anterior, saldo_posterior, motivo, referencia_id) 
                    VALUES (?, ?, 'VENTA_PEDIDOSYA', ?, ?, ?, 'Orden PedidosYa', ?)");
                $stmtMov->execute([$prod['id'], $sucursalId, -$cant, $stockAnt, $stockPost, $orderId]);

                $detallesProcesados[] = [
                    'codigo' => $prod['codigo'],
                    'descripcion' => $prod['descripcion'],
                    'cantidad' => $cant,
                    'stock_restante' => $stockPost
                ];
            }
        }

        // Registrar orden en tabla pedidos
        $codigoPedido = 'PY-' . substr($orderId, -8);
        $sucursalNombre = ($sucursalId === 2) ? 'Haedo' : 'Ramos Mejía';
        $canal = "PEDIDOSYA_" . strtoupper($sucursalNombre);

        $stmtOrd = $pdo->prepare("INSERT INTO pedidos 
            (codigo_pedido, canal, cliente_nombre, cliente_telefono, cliente_direccion, tipo_entrega, costo_envio, subtotal, total, estado, metodo_pago, detalles_json)
            VALUES (?, ?, ?, ?, ?, 'DELIVERY_PEDIDOSYA', 0, ?, ?, 'EN_PREPARACION', 'ONLINE_PEDIDOSYA', ?)");
        
        $stmtOrd->execute([
            $codigoPedido,
            $canal,
            $clienteNombre,
            $clienteTel,
            $direccion,
            $total,
            $total,
            json_encode($items, JSON_UNESCAPED_UNICODE)
        ]);

        $pdo->commit();

        echo json_encode([
            'status' => 'ok',
            'mensaje' => 'Orden de PedidosYa procesada y stock descontado exitosamente.',
            'codigo_pedido' => $codigoPedido,
            'sucursal' => $sucursalNombre,
            'items_procesados' => $detallesProcesados
        ]);
        exit;
    }

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => $e->getMessage()]);
}