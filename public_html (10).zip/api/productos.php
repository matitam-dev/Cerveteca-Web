<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Cache-Control: no-cache, no-store, must-revalidate');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/conexion.php';

try {
    $pdo = obtenerPDO();

    // Asegurar division de sucursales Ramos Mejia (ID 1) y Haedo (ID 2)
    try {
        $pdo->exec("INSERT INTO `sucursales` (`id`, `nombre`, `direccion`, `telefono`, `activo`) VALUES 
            (1, 'Local Ramos Mejía', 'Av. de Mayo 340, Ramos Mejía', '+54 9 11 5654-8303', 1),
            (2, 'Local Haedo', 'Av. Rivadavia 16100, Haedo', '+54 9 11 5654-8303', 1)
            ON DUPLICATE KEY UPDATE `nombre` = VALUES(`nombre`), `direccion` = VALUES(`direccion`)");
    } catch (Throwable $eSuc) {}

    $sucursalParam = trim((string)($_GET['sucursal_id'] ?? 'all'));

    $stockCase = "(COALESCE(i1.cantidad, p.stock_actual, 0) + COALESCE(i2.cantidad, 0))";
    if ($sucursalParam === '1') {
        $stockCase = "COALESCE(i1.cantidad, p.stock_actual, 0)";
    } elseif ($sucursalParam === '2') {
        $stockCase = "COALESCE(i2.cantidad, 0)";
    }

    $sql = "SELECT 
                p.id,
                p.codigo AS Codigo,
                p.codigo AS sku,
                p.descripcion AS Descripcion,
                p.descripcion AS nombre,
                p.precio_final AS Venta,
                p.precio_final AS precio_base,
                p.precio2 AS Precio2,
                p.costo AS Costo,
                p.codigo_barra AS CodigoBarra,
                p.rubro AS Rubro,
                p.subrubro AS Subrubro,
                p.marca AS Marca,
                p.caracteristica AS Caracteristica,
                p.alicuota_iva AS TasaIVA,
                p.oferta AS Oferta,
                COALESCE(i1.cantidad, p.stock_actual, 0) AS Stock_Ramos,
                COALESCE(i2.cantidad, 0) AS Stock_Haedo,
                {$stockCase} AS Stock
            FROM productos p
            LEFT JOIN inventarios i1 ON p.id = i1.producto_id AND i1.sucursal_id = 1
            LEFT JOIN inventarios i2 ON p.id = i2.producto_id AND i2.sucursal_id = 2
            WHERE p.activo = 1
            ORDER BY p.rubro ASC, p.descripcion ASC";

    $stmt = $pdo->query($sql);
    $productos = $stmt->fetchAll();

    if (!empty($productos)) {
        echo json_encode($productos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
} catch (Throwable $e) {
    error_log("Fallback a productos.json: " . $e->getMessage());
}

$jsonPath = dirname(__DIR__) . '/productos.json';
if (file_exists($jsonPath)) {
    readfile($jsonPath);
} else {
    echo json_encode([]);
}