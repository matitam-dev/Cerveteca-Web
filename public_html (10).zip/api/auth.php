<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/config.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?? [];
$action = $data['action'] ?? $_GET['action'] ?? '';

// Lista exhaustiva de usuarios y correos admitidos
$validUsers = [
    'admin',
    'u761001659_admin',
    'u761001659',
    'carlcarson999@gmail.com',
    'contacto@perdedoreshermosos.com.ar',
    'hermososperdedores'
];

// Lista de contraseñas admitidas
$validPasswords = [
    'Perdedores2026!',
    'Perdedores2026',
    'Perdedo3.',
    'Perdedo3'
];

if ($action === 'login') {
    $usuario = strtolower(trim((string)($data['usuario'] ?? '')));
    $password = trim((string)($data['password'] ?? ''));

    $userValido = in_array($usuario, $validUsers, true) || 
                  strpos($usuario, 'carlcarson') !== false || 
                  strpos($usuario, 'admin') !== false || 
                  strpos($usuario, 'perdedor') !== false ||
                  strpos($usuario, '@') !== false;

    $passValida = in_array($password, $validPasswords, true);

    if ($userValido && $passValida) {
        $_SESSION['admin_auth'] = true;
        $_SESSION['admin_user'] = $usuario;
        $_SESSION['login_time'] = time();

        $token = hash('sha256', $usuario . time() . 'PH_SECRET_KEY_2026');
        $_SESSION['admin_token'] = $token;

        // Responder siempre HTTP 200 con JSON
        http_response_code(200);
        echo json_encode([
            'status' => 'ok',
            'mensaje' => 'Inicio de sesión exitoso',
            'usuario' => $usuario,
            'nombre' => 'Administrador PH (' . $usuario . ')',
            'token' => $token
        ]);
        exit;
    } else {
        http_response_code(200);
        echo json_encode([
            'status' => 'error',
            'mensaje' => 'Usuario o contraseña no reconocidos. Podés ingresar con usuario "admin" o "u761001659_admin" o tu email, y contraseña "Perdedores2026!" o "Perdedo3."'
        ]);
        exit;
    }
}

if ($action === 'check') {
    $isAuth = !empty($_SESSION['admin_auth']) && $_SESSION['admin_auth'] === true;
    http_response_code(200);
    echo json_encode([
        'status' => 'ok',
        'authenticated' => $isAuth,
        'usuario' => $_SESSION['admin_user'] ?? null
    ]);
    exit;
}

if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();

    http_response_code(200);
    echo json_encode([
        'status' => 'ok',
        'mensaje' => 'Sesión cerrada correctamente'
    ]);
    exit;
}

http_response_code(200);
echo json_encode([
    'status' => 'ok',
    'mensaje' => 'API de Autenticación ERP Hermosos Perdedores activa'
]);