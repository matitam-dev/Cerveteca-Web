<?php
declare(strict_types=1);

/**
 * Conexión Inteligente y Auto-recuperable a Base de Datos
 * Resuelve automáticamente problemas de Socket vs TCP (localhost vs 127.0.0.1)
 * y prueba variantes de contraseña (con punto final y sin punto)
 */

function obtenerPDO(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $db = 'u761001659_catalogo';
    $user = 'u761001659_admin';
    
    // Lista de combinaciones de host a probar
    $hosts = ['localhost', '127.0.0.1'];
    // Probar ambas variantes: con punto y sin punto final
    $passwords = ['Perdedo3.', 'Perdedo3'];

    $esLocal = in_array($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1', ['127.0.0.1', '::1']);

    if ($esLocal) {
        // En entorno local XAMPP probar primero root sin password
        try {
            $dsn = "mysql:host=127.0.0.1;port=3306;dbname={$db};charset=utf8mb4";
            $pdo = new PDO($dsn, 'root', '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
            return $pdo;
        } catch (PDOException $e) {
            // Continuar a probar credenciales de produccion
        }
    }

    $intentosFallidos = [];

    foreach ($hosts as $host) {
        foreach ($passwords as $pass) {
            try {
                $dsn = "mysql:host={$host};port=3306;dbname={$db};charset=utf8mb4";
                $pdo = new PDO($dsn, $user, $pass, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ]);
                return $pdo;
            } catch (PDOException $e) {
                $etiquetaPass = (substr($pass, -1) === '.') ? 'con punto [Perdedo3.]' : 'sin punto [Perdedo3]';
                $intentosFallidos[] = "Host: $host, Clave: $etiquetaPass -> " . $e->getMessage();
            }
        }
    }

    $mensajeError = implode(" \n ", $intentosFallidos);
    error_log("Error MySQL detallado: " . $mensajeError);
    throw new Exception("Error de conexión MySQL en Hostinger: " . $mensajeError);
}
