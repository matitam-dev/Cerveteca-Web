<?php
declare(strict_types=1);

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Diagnóstico Base de Datos</title>";
echo "<style>
body { font-family: monospace; background: #0c0c0c; color: #fff; padding: 30px; line-height: 1.6; }
.card { background: #181818; border: 1px solid #333; border-radius: 8px; padding: 20px; max-width: 800px; margin: 0 auto; }
.success { color: #00ff66; font-weight: bold; }
.error { color: #ff4444; font-weight: bold; }
.info { color: #ffbb00; }
a { color: #0099ff; text-decoration: none; font-weight: bold; }
</style></head><body>";

echo "<div class='card'>";
echo "<h2>HERMOSOS PERDEDORES &bull; DIAGNÓSTICO DE BASE DE DATOS</h2>";
echo "<p>Probando conexión hacia <strong>u761001659_catalogo</strong>...</p><hr style='border-color:#333; margin:15px 0;'>";

require_once __DIR__ . '/conexion.php';

try {
    $pdo = obtenerPDO();
    echo "<p class='success'><span style='font-size:20px;'>✔</span> ¡CONEXIÓN EXITOSA CON MARIADB / MYSQL EN HOSTINGER!</p>";
    
    // Obtener tablas existentes
    $tablas = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<p><strong>Tablas detectadas (" . count($tablas) . "):</strong> " . implode(", ", $tablas) . "</p>";

    if (in_array('productos', $tablas)) {
        $cantProds = $pdo->query("SELECT COUNT(*) FROM productos")->fetchColumn();
        echo "<p class='info'><strong>Artículos en tabla 'productos':</strong> $cantProds</p>";
    } else {
        echo "<p class='error'>La tabla 'productos' aún no fue creada.</p>";
    }

    if (in_array('inventarios', $tablas)) {
        $cantInv = $pdo->query("SELECT COUNT(*) FROM inventarios")->fetchColumn();
        $stockTotal = $pdo->query("SELECT SUM(cantidad) FROM inventarios")->fetchColumn();
        echo "<p class='info'><strong>Registros en 'inventarios':</strong> $cantInv | <strong>Stock Físico Total:</strong> $stockTotal u.</p>";
    }

    echo "<hr style='border-color:#333; margin:15px 0;'>";
    echo "<p><a href='importar_productos.php'>👉 Ejecutar / Reimportar Catálogo Completo (importar_productos.php)</a></p>";
    echo "<p><a href='../index.html'>👉 Volver a la Tienda Web (index.html)</a> | <a href='../pos.html'>👉 Abrir POS Mostrador (pos.html)</a></p>";

} catch (Throwable $e) {
    echo "<p class='error'><span style='font-size:20px;'>✖</span> NO SE PUDO CONECTAR A MYSQL</p>";
    echo "<p><strong>Detalle del error del servidor:</strong></p>";
    echo "<pre style='background:#000; padding:15px; border-left:4px solid #f00; color:#ff8888; overflow-x:auto;'>" . htmlspecialchars($e->getMessage()) . "</pre>";
    
    echo "<h3>¿Cómo solucionarlo en Hostinger hPanel?</h3>";
    echo "<ol>";
    echo "<li>Ingresa a tu panel de Hostinger (<strong>hPanel</strong>) > <strong>Bases de Datos</strong>.</li>";
    echo "<li>Verifica que el nombre exacto de la base sea <code>u761001659_catalogo</code>.</li>";
    echo "<li>Verifica que el usuario asociado sea <code>u761001659_admin</code> y que tenga <strong>todos los privilegios</strong> otorgados.</li>";
    echo "<li>En los 3 puntos verticales junto al usuario, pulsa <strong>Cambiar Contraseña</strong> y escribe <code>Perdedo3.</code> (o la clave que prefieras) y pulsa Guardar.</li>";
    echo "</ol>";
}

echo "</div></body></html>";
