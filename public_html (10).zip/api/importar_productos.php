<?php
declare(strict_types=1);

require_once __DIR__ . '/conexion.php';

$esCli = (php_sapi_name() === 'cli');

if (!$esCli) {
    header('Content-Type: text/html; charset=utf-8');
    echo "<pre style='background:#0a0a0a; color:#00ff66; padding:25px; font-family:monospace; line-height:1.5;'>";
}

echo "===============================================================\n";
echo " HERMOSOS PERDEDORES CERVETECA - IMPORTADOR SQL EN HOSTINGER\n";
echo " Base de Datos: u761001659_catalogo\n";
echo "===============================================================\n\n";

try {
    $pdo = obtenerPDO();
    echo "[OK] Conectado exitosamente con usuario u761001659_admin.\n";

    $sqlPath = dirname(__DIR__) . '/importar_productos.sql';
    if (!file_exists($sqlPath)) {
        throw new Exception("No se encontro el archivo SQL en: " . $sqlPath);
    }

    echo "[INFO] Leyendo archivo importar_productos.sql (" . round(filesize($sqlPath) / 1024, 2) . " KB)...\n";
    $sqlContent = file_get_contents($sqlPath);

    echo "[INFO] Ejecutando sentencias de creacion de tablas e inserciones...\n";
    $pdo->exec($sqlContent);

    $cantProductos = $pdo->query("SELECT COUNT(*) FROM productos")->fetchColumn();
    $cantInventarios = $pdo->query("SELECT COUNT(*) FROM inventarios")->fetchColumn();
    $stockTotal = $pdo->query("SELECT SUM(cantidad) FROM inventarios")->fetchColumn();

    echo "\n[EXITO COMPLETO]:\n";
    echo " -> Tabla 'productos': $cantProductos articulos cargados.\n";
    echo " -> Tabla 'inventarios': $cantInventarios registros en sucursal Casa Central.\n";
    echo " -> Stock total fisico: $stockTotal unidades.\n";
    echo "\n¡Todo el catalogo esta en linea y listo para vender!\n";

} catch (Throwable $e) {
    echo "\n[ERROR FATAL]: " . $e->getMessage() . "\n";
}

if (!$esCli) {
    echo "\n<a href='../index.html' style='color:#fff; background:#8b1c1c; padding:10px 20px; text-decoration:none; display:inline-block; border-radius:5px; font-weight:bold;'>IR AL SITIO WEB</a>";
    echo "</pre>";
}
