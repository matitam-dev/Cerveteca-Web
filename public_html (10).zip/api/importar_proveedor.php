<?php
declare(strict_types=1);

/**
 * ==============================================================================
 * HERMOSOS PERDEDORES CERVETECA - IMPORTADOR DE LISTAS Y FACTURAS DE PROVEEDORES
 * ==============================================================================
 * 1. Actualiza costos y precios de venta en catálogo.
 * 2. Ingresa stock físico a la sucursal seleccionada (Local Ramos Mejía o Haedo).
 * 3. Asienta el egreso de dinero (Salida de Caja / Banco) y el comprobante fiscal
 *    asociado (Factura A/B/C o Remito de compra con crédito fiscal IVA).
 * 4. Mantiene trazabilidad completa en auditoría de movimientos de stock.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/conexion.php';

function asegurarTablasProveedores(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `comprobantes_proveedores` (
        `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `proveedor` VARCHAR(255) NOT NULL,
        `cuit_proveedor` VARCHAR(20) NULL,
        `tipo_comprobante` VARCHAR(50) NOT NULL DEFAULT 'FACTURA_A',
        `numero_comprobante` VARCHAR(50) NOT NULL,
        `fecha_emision` DATE NOT NULL,
        `sucursal_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT 1,
        `subtotal_neto` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        `iva_credito_fiscal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        `total_importe` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        `condicion_pago` VARCHAR(50) NOT NULL DEFAULT 'EFECTIVO_CAJA',
        `archivo_nombre` VARCHAR(255) NULL,
        `cant_articulos` INT(11) NOT NULL DEFAULT 0,
        `cant_unidades` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        `detalles_json` LONGTEXT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_prov` (`proveedor`),
        INDEX `idx_fecha` (`fecha_emision`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

$metodo = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = obtenerPDO();
    asegurarTablasProveedores($pdo);

    if ($metodo === 'GET') {
        // Listar comprobantes de compra de proveedores
        $stmt = $pdo->query("SELECT cp.*, COALESCE(s.nombre, CONCAT('Sucursal ', cp.sucursal_id)) AS sucursal_nombre 
                              FROM comprobantes_proveedores cp 
                              LEFT JOIN sucursales s ON cp.sucursal_id = s.id 
                              ORDER BY cp.created_at DESC LIMIT 50");
        echo json_encode(['status' => 'ok', 'comprobantes' => $stmt->fetchAll()]);
        exit;
    }

    if ($metodo === 'POST') {
        $proveedor = trim((string)($_POST['proveedor'] ?? ''));
        $cuitProveedor = trim((string)($_POST['cuit_proveedor'] ?? ''));
        $tipoComprobante = strtoupper(trim((string)($_POST['tipo_comprobante'] ?? 'FACTURA_A')));
        $numeroComprobante = trim((string)($_POST['numero_comprobante'] ?? ('FC-' . time())));
        $fechaEmision = trim((string)($_POST['fecha_emision'] ?? date('Y-m-d')));
        $sucursalId = (int)($_POST['sucursal_id'] ?? 1);
        $condicionPago = strtoupper(trim((string)($_POST['condicion_pago'] ?? 'EFECTIVO_CAJA')));
        
        $filas = [];
        $nombreArchivo = null;

        // A) Caso subida de archivo CSV
        if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
            $nombreArchivo = $_FILES['archivo']['name'];
            $tmpPath = $_FILES['archivo']['tmp_name'];
            
            $handle = fopen($tmpPath, 'r');
            if ($handle !== false) {
                $header = fgetcsv($handle, 2000, ',');
                if ($header === false || count($header) < 2) {
                    rewind($handle);
                    $header = fgetcsv($handle, 2000, ';'); // Probar con punto y coma
                }

                if ($header) {
                    $headerNorm = array_map(fn($h) => strtolower(trim((string)$h)), $header);
                    
                    // Detectar índices
                    $idxCod = -1; $idxDesc = -1; $idxCosto = -1; $idxVenta = -1; $idxCant = -1;
                    foreach ($headerNorm as $i => $col) {
                        if (str_contains($col, 'cod') || str_contains($col, 'sku')) $idxCod = $i;
                        elseif (str_contains($col, 'desc') || str_contains($col, 'nom') || str_contains($col, 'art')) $idxDesc = $i;
                        elseif (str_contains($col, 'cost') || str_contains($col, 'compra')) $idxCosto = $i;
                        elseif (str_contains($col, 'vent') || str_contains($col, 'prec') || str_contains($col, 'pvp')) $idxVenta = $i;
                        elseif (str_contains($col, 'cant') || str_contains($col, 'stk') || str_contains($col, 'ingres')) $idxCant = $i;
                    }

                    while (($row = fgetcsv($handle, 2000, ',')) !== false) {
                        if (count($row) < 2) continue;
                        $filas[] = [
                            'codigo' => $idxCod >= 0 ? trim((string)($row[$idxCod] ?? '')) : trim((string)$row[0]),
                            'descripcion' => $idxDesc >= 0 ? trim((string)($row[$idxDesc] ?? '')) : trim((string)($row[1] ?? '')),
                            'costo' => $idxCosto >= 0 ? (float)str_replace(',', '.', (string)($row[$idxCosto] ?? 0)) : 0.0,
                            'venta' => $idxVenta >= 0 ? (float)str_replace(',', '.', (string)($row[$idxVenta] ?? 0)) : 0.0,
                            'cantidad' => $idxCant >= 0 ? (float)str_replace(',', '.', (string)($row[$idxCant] ?? 0)) : 0.0,
                        ];
                    }
                }
                fclose($handle);
            }
        } 
        // B) Caso JSON directo enviado desde el modal de ERP
        else {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true);
            if ($data) {
                $proveedor = trim((string)($data['proveedor'] ?? $proveedor));
                $cuitProveedor = trim((string)($data['cuit_proveedor'] ?? $cuitProveedor));
                $tipoComprobante = strtoupper(trim((string)($data['tipo_comprobante'] ?? $tipoComprobante)));
                $numeroComprobante = trim((string)($data['numero_comprobante'] ?? $numeroComprobante));
                $fechaEmision = trim((string)($data['fecha_emision'] ?? $fechaEmision));
                $sucursalId = (int)($data['sucursal_id'] ?? $sucursalId);
                $condicionPago = strtoupper(trim((string)($data['condicion_pago'] ?? $condicionPago)));
                $filas = $data['items'] ?? $data['filas'] ?? [];
            }
        }

        if (empty($filas)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'No se encontraron artículos para procesar en el archivo o lote.']);
            exit;
        }

        if ($proveedor === '') {
            $proveedor = 'Distribuidora Cervecera';
        }

        $pdo->beginTransaction();

        $subtotalCompra = 0.0;
        $totalUnidades = 0.0;
        $articulosProcesados = [];

        foreach ($filas as $f) {
            $cod = trim((string)($f['codigo'] ?? ''));
            $desc = trim((string)($f['descripcion'] ?? ''));
            $costo = (float)($f['costo'] ?? 0);
            $venta = (float)($f['venta'] ?? 0);
            $cant = (float)($f['cantidad'] ?? 0);

            if ($cod === '' && $desc === '') continue;
            if ($cod === '') $cod = 'PROV-' . strtoupper(substr(md5($desc), 0, 8));

            $itemSubtotal = $costo * $cant;
            $subtotalCompra += $itemSubtotal;
            $totalUnidades += $cant;

            // 1. Buscar si el producto existe en la base de datos
            $stmtB = $pdo->prepare("SELECT id, codigo, descripcion, costo, precio_final, stock_actual FROM productos WHERE codigo = ? OR descripcion = ? LIMIT 1 FOR UPDATE");
            $stmtB->execute([$cod, $desc]);
            $prod = $stmtB->fetch();

            $prodId = 0;
            if ($prod) {
                $prodId = (int)$prod['id'];
                // Actualizar costo y venta (si venta es 0 se calcula con markup del 40%)
                $nuevaVenta = ($venta > 0) ? $venta : round($costo * 1.40, -1);
                $nuevoCosto = ($costo > 0) ? $costo : (float)$prod['costo'];

                $stmtUpP = $pdo->prepare("UPDATE productos SET costo = ?, precio_final = ?, proveedor = ?, stock_actual = stock_actual + ? WHERE id = ?");
                $stmtUpP->execute([$nuevoCosto, $nuevaVenta, $proveedor, $cant, $prodId]);
            } else {
                // Crear nuevo producto en catálogo
                $nuevaVenta = ($venta > 0) ? $venta : round($costo * 1.40, -1);
                $stmtInsP = $pdo->prepare("INSERT INTO productos 
                    (codigo, descripcion, rubro, costo, precio_final, stock_actual, proveedor, activo)
                    VALUES (?, ?, 'GENERALES', ?, ?, ?, ?, 1)");
                $stmtInsP->execute([$cod, $desc, $costo, $nuevaVenta, $cant, $proveedor]);
                $prodId = (int)$pdo->lastInsertId();
            }

            // 2. Sumar stock físico en la sucursal seleccionada
            $stmtStk = $pdo->prepare("SELECT cantidad FROM inventarios WHERE producto_id = ? AND sucursal_id = ? FOR UPDATE");
            $stmtStk->execute([$prodId, $sucursalId]);
            $saldoAnt = (float)($stmtStk->fetchColumn() ?: 0);
            $saldoPost = $saldoAnt + $cant;

            $stmtUpInv = $pdo->prepare("INSERT INTO inventarios (producto_id, sucursal_id, cantidad, ubicacion)
                                         VALUES (?, ?, ?, 'DEPOSITO')
                                         ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
            $stmtUpInv->execute([$prodId, $sucursalId, $saldoPost]);

            // 3. Registrar en auditoría de movimientos de stock
            $stmtMov = $pdo->prepare("INSERT INTO movimientos_stock 
                (producto_id, sucursal_id, tipo, cantidad, saldo_anterior, saldo_posterior, motivo, referencia_id)
                VALUES (?, ?, 'INGRESO_PROVEEDOR', ?, ?, ?, ?, ?)");
            $stmtMov->execute([
                $prodId,
                $sucursalId,
                $cant,
                $saldoAnt,
                $saldoPost,
                "Ingreso Compra $tipoComprobante $numeroComprobante de $proveedor",
                $numeroComprobante
            ]);

            $articulosProcesados[] = [
                'codigo' => $cod,
                'descripcion' => $desc ?: $prod['descripcion'],
                'costo' => $costo,
                'venta' => $nuevaVenta,
                'cantidad_ingresada' => $cant,
                'stock_sucursal_final' => $saldoPost
            ];
        }

        // 4. Calcular crédito fiscal IVA 21% si es Factura A
        $ivaCredito = ($tipoComprobante === 'FACTURA_A') ? round($subtotalCompra * 0.21, 2) : 0.00;
        $totalEgreso = $subtotalCompra + $ivaCredito;

        // 5. Asentar comprobante de compra y egreso de dinero
        $stmtComp = $pdo->prepare("INSERT INTO comprobantes_proveedores 
            (proveedor, cuit_proveedor, tipo_comprobante, numero_comprobante, fecha_emision, sucursal_id, subtotal_neto, iva_credito_fiscal, total_importe, condicion_pago, archivo_nombre, cant_articulos, cant_unidades, detalles_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmtComp->execute([
            $proveedor,
            $cuitProveedor,
            $tipoComprobante,
            $numeroComprobante,
            $fechaEmision,
            $sucursalId,
            $subtotalCompra,
            $ivaCredito,
            $totalEgreso,
            $condicionPago,
            $nombreArchivo,
            count($articulosProcesados),
            $totalUnidades,
            json_encode($articulosProcesados, JSON_UNESCAPED_UNICODE)
        ]);

        $comprobanteId = (int)$pdo->lastInsertId();

        // 6. Actualizar productos.json en disco para reflejar nuevos precios y stock
        try {
            $jsonFile = dirname(__DIR__) . '/productos.json';
            if (file_exists($jsonFile) && is_writable($jsonFile)) {
                $stmtAll = $pdo->query("SELECT p.codigo AS Codigo, p.descripcion AS Descripcion, p.rubro AS Rubro, p.precio_final AS Venta, p.costo AS Costo, p.stock_actual AS Stock FROM productos p WHERE p.activo = 1");
                file_put_contents($jsonFile, json_encode($stmtAll->fetchAll(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
            }
        } catch (Throwable $eJ) {}

        $pdo->commit();

        $sucursalNombre = ($sucursalId === 2) ? 'Local Haedo' : 'Local Ramos Mejía';

        echo json_encode([
            'status' => 'ok',
            'mensaje' => "Comprobante de compra y catálogo procesados con éxito en $sucursalNombre.",
            'resumen' => [
                'comprobante_id' => $comprobanteId,
                'proveedor' => $proveedor,
                'tipo_comprobante' => $tipoComprobante,
                'numero_comprobante' => $numeroComprobante,
                'sucursal' => $sucursalNombre,
                'articulos_impactados' => count($articulosProcesados),
                'total_unidades_ingresadas' => $totalUnidades,
                'subtotal_compra' => $subtotalCompra,
                'iva_credito_fiscal' => $ivaCredito,
                'total_egreso_dinero' => $totalEgreso,
                'condicion_pago' => $condicionPago
            ],
            'items' => $articulosProcesados
        ]);
        exit;
    }

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => $e->getMessage()]);
}