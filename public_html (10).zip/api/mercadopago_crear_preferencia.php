<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once dirname(__DIR__) . '/config.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || !isset($data['items'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'Datos requeridos no recibidos']);
    exit;
}

$itemsMP = [];
foreach ($data['items'] as $it) {
    $itemsMP[] = [
        "title" => (string)$it['descripcion'],
        "quantity" => (int)$it['cantidad'],
        "unit_price" => (float)$it['precio'],
        "currency_id" => "ARS"
    ];
}

$costoEnvio = (float)($data['costo_envio'] ?? 0);
if ($costoEnvio > 0 && ($data['tipo_entrega'] ?? '') === 'ENVIO') {
    $itemsMP[] = [
        "title" => "Costo de Envío a Domicilio - Villa Luzuriaga / Zona Oeste",
        "quantity" => 1,
        "unit_price" => $costoEnvio,
        "currency_id" => "ARS"
    ];
}

$preferenceData = [
    "items" => $itemsMP,
    "payer" => [
        "name" => (string)($data['cliente_nombre'] ?? 'Cliente'),
        "phone" => ["number" => (string)($data['cliente_telefono'] ?? '')]
    ],
    "back_urls" => [
        "success" => APP_URL . "/index.html?pago=exito",
        "failure" => APP_URL . "/index.html?pago=error",
        "pending" => APP_URL . "/index.html?pago=pendiente"
    ],
    "auto_return" => "approved",
    "external_reference" => "HP-WEB-" . time()
];

// cURL a la API de Mercado Pago
$ch = curl_init("https://api.mercadopago.com/checkout/preferences");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer " . MP_ACCESS_TOKEN,
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($preferenceData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$resData = json_decode($response, true);

if ($httpCode >= 200 && $httpCode < 300 && isset($resData['init_point'])) {
    echo json_encode(['status' => 'ok', 'init_point' => $resData['init_point']]);
} else {
    // Si no configuraron el token real todavía, dar mensaje guiado
    echo json_encode([
        'status' => 'error', 
        'mensaje' => 'Configura tu MP_ACCESS_TOKEN en config.php para procesar el pago automático en vivo.'
    ]);
}
