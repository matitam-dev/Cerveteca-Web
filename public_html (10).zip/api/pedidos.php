<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/conexion.php';

$metodo = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = obtenerPDO();

    if ($metodo === 'GET') {
        $stmt = $pdo->query("SELECT * FROM pedidos ORDER BY created_at DESC LIMIT 50");
        echo json_encode(['status' => 'ok', 'pedidos' => $stmt->fetchAll()]);
        exit;
    }

    if ($metodo === 'POST') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'JSON invalido']);
            exit;
        }

        $codigoPedido = 'HP-' . strtoupper(substr(uniqid(), -6));
        $canal = $data['origen'] ?? $data['canal'] ?? 'WEB_WHATSAPP';
        $nombre = $data['cliente_nombre'] ?? 'Cliente';
        $telefono = $data['cliente_telefono'] ?? '';
        $direccion = $data['direccion_envio'] ?? $data['cliente_direccion'] ?? '';
        $tipoEntrega = $data['tipo_entrega'] ?? 'RETIRO';
        $costoEnvio = (float)($data['costo_envio'] ?? 0);
        $total = (float)($data['total'] ?? 0);
        $subtotal = max(0, $total - $costoEnvio);
        $items = $data['items'] ?? [];
        $metodoPago = $data['metodo_pago'] ?? 'TRANSFERENCIA';

        $stmt = $pdo->prepare("INSERT INTO pedidos 
            (codigo_pedido, canal, cliente_nombre, cliente_telefono, cliente_direccion, tipo_entrega, costo_envio, subtotal, total, estado, metodo_pago, detalles_json) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDIENTE', ?, ?)");
        
        $stmt->execute([
            $codigoPedido,
            $canal,
            $nombre,
            $telefono,
            $direccion,
            $tipoEntrega,
            $costoEnvio,
            $subtotal,
            $total,
            $metodoPago,
            json_encode($items, JSON_UNESCAPED_UNICODE)
        ]);

        echo json_encode([
            'status' => 'ok',
            'codigo_pedido' => $codigoPedido,
            'mensaje' => 'Pedido registrado correctamente en el ERP.'
        ]);
        exit;
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => $e->getMessage()]);
}
