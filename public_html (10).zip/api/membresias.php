<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/conexion.php';

$metodo = $_SERVER['REQUEST_METHOD'];

function asegurarTablasMembresias(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `membresias` (
        `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `codigo_socio` VARCHAR(50) NOT NULL UNIQUE,
        `plan` VARCHAR(50) NOT NULL DEFAULT 'PH_60K',
        `precio_mensual` DECIMAL(12,2) NOT NULL DEFAULT 60000.00,
        `nombre_apellido` VARCHAR(255) NOT NULL,
        `dni` VARCHAR(20) NOT NULL,
        `fecha_nacimiento` DATE NULL DEFAULT NULL,
        `telefono` VARCHAR(50) NOT NULL,
        `email` VARCHAR(100) NULL DEFAULT NULL,
        `domicilio` VARCHAR(255) NOT NULL,
        `depto` VARCHAR(50) NULL DEFAULT NULL,
        `codigo_postal` VARCHAR(20) NOT NULL,
        `localidad` VARCHAR(100) NOT NULL,
        `preferencias_cervezas` TEXT NULL DEFAULT NULL,
        `puntos_acumulados` INT(11) NOT NULL DEFAULT 0,
        `estado` VARCHAR(50) NOT NULL DEFAULT 'ACTIVO',
        `metodo_pago` VARCHAR(50) NOT NULL DEFAULT 'MERCADOPAGO',
        `fecha_alta` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `proximo_envio` DATE NULL DEFAULT NULL,
        `notas` TEXT NULL DEFAULT NULL,
        INDEX `idx_socio_dni` (`dni`),
        INDEX `idx_socio_estado` (`estado`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `canjes_puntos` (
        `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `socio_id` INT(11) NOT NULL,
        `puntos_usados` INT(11) NOT NULL,
        `premio` VARCHAR(255) NOT NULL,
        `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

try {
    $pdo = obtenerPDO();
    asegurarTablasMembresias($pdo);

    // ==========================================
    // 1. GET: Consultas y Listados
    // ==========================================
    if ($metodo === 'GET') {
        // A) Buscar socio individual por DNI o Código de Socio
        if (isset($_GET['dni']) || isset($_GET['codigo_socio'])) {
            $busqueda = trim((string)($_GET['dni'] ?? $_GET['codigo_socio']));
            $stmt = $pdo->prepare("SELECT * FROM membresias WHERE dni = ? OR codigo_socio = ? LIMIT 1");
            $stmt->execute([$busqueda, $busqueda]);
            $socio = $stmt->fetch();

            if (!$socio) {
                http_response_code(404);
                echo json_encode(['status' => 'error', 'mensaje' => 'Socio no encontrado']);
                exit;
            }

            // Calcular descuentos aplicables según plan del PDF
            $descuentoCervezas = 0.0;
            $descuentoOtros = 0.0;
            if ($socio['estado'] === 'ACTIVO') {
                if ($socio['plan'] === 'PH_60K') {
                    $descuentoCervezas = 15.0; // 15% en cervezas
                    $descuentoOtros = 10.0;    // 10% en destilados, vinos, aperitivos
                } elseif ($socio['plan'] === 'DORADA') {
                    $descuentoCervezas = 20.0;
                    $descuentoOtros = 15.0;
                } else { // CLASICA
                    $descuentoCervezas = 10.0;
                    $descuentoOtros = 10.0;
                }
            }

            echo json_encode([
                'status' => 'ok',
                'socio' => $socio,
                'beneficios' => [
                    'descuento_cervezas' => $descuentoCervezas,
                    'descuento_otros' => $descuentoOtros,
                    'envio_mensual_gratis' => true,
                    'periodo_envio' => '1 al 10 del mes'
                ]
            ]);
            exit;
        }

        // B) Resumen para dashboard ERP
        if (isset($_GET['resumen'])) {
            $totalSocios = (int)$pdo->query("SELECT COUNT(*) FROM membresias WHERE estado = 'ACTIVO'")->fetchColumn();
            $mrr = (float)$pdo->query("SELECT COALESCE(SUM(precio_mensual), 0) FROM membresias WHERE estado = 'ACTIVO'")->fetchColumn();
            $puntosTotales = (int)$pdo->query("SELECT COALESCE(SUM(puntos_acumulados), 0) FROM membresias WHERE estado = 'ACTIVO'")->fetchColumn();
            $porPlan = $pdo->query("SELECT plan, COUNT(*) as cantidad, SUM(precio_mensual) as total FROM membresias WHERE estado = 'ACTIVO' GROUP BY plan")->fetchAll();

            echo json_encode([
                'status' => 'ok',
                'total_socios_activos' => $totalSocios,
                'ingreso_mensual_mrr' => $mrr,
                'puntos_totales_club' => $puntosTotales,
                'desglose_planes' => $porPlan
            ]);
            exit;
        }

        // C) Listar todos los socios para el panel ERP
        $filtroPlan = $_GET['plan'] ?? null;
        $filtroEstado = $_GET['estado'] ?? null;

        $sql = "SELECT * FROM membresias WHERE 1=1";
        $params = [];

        if ($filtroPlan) {
            $sql .= " AND plan = ?";
            $params[] = $filtroPlan;
        }
        if ($filtroEstado) {
            $sql .= " AND estado = ?";
            $params[] = $filtroEstado;
        }

        $sql .= " ORDER BY fecha_alta DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $socios = $stmt->fetchAll();

        echo json_encode(['status' => 'ok', 'socios' => $socios]);
        exit;
    }

    // ==========================================
    // 2. POST: Alta de Nueva Membresía
    // ==========================================
    if ($metodo === 'POST') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'Datos inválidos. JSON esperado.']);
            exit;
        }

        // Validación de campos requeridos del PDF
        $nombre = trim((string)($data['nombre_apellido'] ?? ''));
        $dni = trim((string)($data['dni'] ?? ''));
        $telefono = trim((string)($data['telefono'] ?? ''));
        $domicilio = trim((string)($data['domicilio'] ?? ''));
        $codigoPostal = trim((string)($data['codigo_postal'] ?? ''));
        $localidad = trim((string)($data['localidad'] ?? ''));
        $plan = strtoupper(trim((string)($data['plan'] ?? 'PH_60K')));
        $metodoPago = strtoupper(trim((string)($data['metodo_pago'] ?? 'MERCADOPAGO')));

        if ($nombre === '' || $dni === '' || $telefono === '' || $domicilio === '' || $codigoPostal === '' || $localidad === '') {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'mensaje' => 'Campos obligatorios incompletos: Nombre y Apellido, DNI, Teléfono, Domicilio, Código Postal y Localidad son requeridos.'
            ]);
            exit;
        }

        // Verificar si ya existe socio con ese DNI
        $stmtDni = $pdo->prepare("SELECT id, codigo_socio, estado FROM membresias WHERE dni = ? LIMIT 1");
        $stmtDni->execute([$dni]);
        $existente = $stmtDni->fetch();

        if ($existente) {
            http_response_code(409);
            echo json_encode([
                'status' => 'error',
                'mensaje' => "El DNI $dni ya se encuentra registrado con el número de socio {$existente['codigo_socio']} (Estado: {$existente['estado']})."
            ]);
            exit;
        }

        // Definir precio mensual y puntos según plan
        $preciosPlan = [
            'CLASICA' => 45000.00,
            'PH_60K'  => 60000.00,
            'DORADA'  => 85000.00
        ];
        $precioMensual = $preciosPlan[$plan] ?? 60000.00;
        $puntosIniciales = (int)$precioMensual; // $1 = 1 punto

        // Generar código de socio único: PH-XXXX
        $codigoSocio = 'PH-' . strtoupper(substr(uniqid(), -5));

        // Calcular fecha primer envío (próximo rango del 1 al 10)
        $diaActual = (int)date('j');
        if ($diaActual <= 10) {
            $proximoEnvio = date('Y-m-') . '05'; // Mismo mes
        } else {
            $proximoEnvio = date('Y-m-05', strtotime('+1 month')); // Próximo mes
        }

        $fechaNac = !empty($data['fecha_nacimiento']) ? (string)$data['fecha_nacimiento'] : null;
        $email = !empty($data['email']) ? trim((string)$data['email']) : null;
        $depto = !empty($data['depto']) ? trim((string)$data['depto']) : null;
        $preferencias = isset($data['preferencias_cervezas']) ? json_encode($data['preferencias_cervezas'], JSON_UNESCAPED_UNICODE) : null;
        $notas = $data['notas'] ?? null;

        $stmtIns = $pdo->prepare("INSERT INTO membresias 
            (codigo_socio, plan, precio_mensual, nombre_apellido, dni, fecha_nacimiento, telefono, email, domicilio, depto, codigo_postal, localidad, preferencias_cervezas, puntos_acumulados, estado, metodo_pago, proximo_envio, notas)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVO', ?, ?, ?)");

        $stmtIns->execute([
            $codigoSocio,
            $plan,
            $precioMensual,
            $nombre,
            $dni,
            $fechaNac,
            $telefono,
            $email,
            $domicilio,
            $depto,
            $codigoPostal,
            $localidad,
            $preferencias,
            $puntosIniciales,
            $metodoPago,
            $proximoEnvio,
            $notas
        ]);

        $socioId = (int)$pdo->lastInsertId();

        // Enlace WhatsApp de confirmación inmediata
        $mensajeWsp = "¡Hola Hermosos Perdedores! Me acabo de suscribir a la *Membresía $plan* con el código de socio *$codigoSocio*.
";
        $mensajeWsp .= "Mi nombre es *$nombre* (DNI: $dni).
";
        $mensajeWsp .= "Mi dirección de entrega es: $domicilio, $localidad.
";
        $mensajeWsp .= "Forma de pago elegida: $metodoPago.";
        $wspUrl = "https://wa.me/5491156548303?text=" . urlencode($mensajeWsp);

        echo json_encode([
            'status' => 'ok',
            'mensaje' => '¡Bienvenido a PH Club! Tu suscripción fue activada con éxito.',
            'codigo_socio' => $codigoSocio,
            'plan' => $plan,
            'precio_mensual' => $precioMensual,
            'puntos_ganados' => $puntosIniciales,
            'proximo_envio' => $proximoEnvio,
            'wsp_url' => $wspUrl
        ]);
        exit;
    }

    // ==========================================
    // 3. PUT: Actualización de Socio (Puntos, Estado, Envíos)
    // ==========================================
    if ($metodo === 'PUT') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        if (!$data || !isset($data['id'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'mensaje' => 'Se requiere el ID del socio']);
            exit;
        }

        $id = (int)$data['id'];
        $campos = [];
        $params = [];

        if (isset($data['estado'])) {
            $campos[] = "estado = ?";
            $params[] = strtoupper(trim((string)$data['estado']));
        }
        if (isset($data['puntos_acumulados'])) {
            $campos[] = "puntos_acumulados = ?";
            $params[] = (int)$data['puntos_acumulados'];
        }
        if (isset($data['puntos_a_sumar'])) {
            $campos[] = "puntos_acumulados = puntos_acumulados + ?";
            $params[] = (int)$data['puntos_a_sumar'];
        }
        if (isset($data['puntos_a_canjear'])) {
            $pts = (int)$data['puntos_a_canjear'];
            $premio = (string)($data['premio'] ?? 'Canje de producto');
            $campos[] = "puntos_acumulados = GREATEST(0, puntos_acumulados - ?)";
            $params[] = $pts;

            // Registrar canje
            $stmtCanje = $pdo->prepare("INSERT INTO canjes_puntos (socio_id, puntos_usados, premio) VALUES (?, ?, ?)");
            $stmtCanje->execute([$id, $pts, $premio]);
        }
        if (isset($data['proximo_envio'])) {
            $campos[] = "proximo_envio = ?";
            $params[] = (string)$data['proximo_envio'];
        }
        if (isset($data['notas'])) {
            $campos[] = "notas = ?";
            $params[] = (string)$data['notas'];
        }

        if (empty($campos)) {
            echo json_encode(['status' => 'error', 'mensaje' => 'Nada para actualizar']);
            exit;
        }

        $params[] = $id;
        $sql = "UPDATE membresias SET " . implode(", ", $campos) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        echo json_encode(['status' => 'ok', 'mensaje' => 'Socio actualizado correctamente']);
        exit;
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => $e->getMessage()]);
}