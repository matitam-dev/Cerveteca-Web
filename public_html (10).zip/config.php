<?php
declare(strict_types=1);

/**
 * CONFIGURACION GENERAL - HERMOSOS PERDEDORES CERVETECA
 * Hostinger: perdedoreshermosos.com.ar
 */

define('APP_NAME', 'Hermosos Perdedores Cerveteca');
define('APP_URL', 'https://perdedoreshermosos.com.ar');
define('TELEFONO_WHATSAPP', '5491156548303');
define('COSTO_ENVIO_FIJO', 2500.0);

// Sucursales Oficiales
define('SUCURSAL_1_ID', 1);
define('SUCURSAL_1_NOMBRE', 'Local Ramos Mejía');
define('SUCURSAL_1_DIRECCION', 'Av. de Mayo 340, Ramos Mejía');

define('SUCURSAL_2_ID', 2);
define('SUCURSAL_2_NOMBRE', 'Local Haedo');
define('SUCURSAL_2_DIRECCION', 'Av. Rivadavia 16100, Haedo');

// Autenticacion Panel de Administracion ERP
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'Perdedores2026!');

// Base de Datos Hostinger
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'u761001659_catalogo');
define('DB_USER', 'u761001659_admin');
define('DB_PASS', 'Perdedo3.');

// Mercado Pago
define('MP_ACCESS_TOKEN', 'APP_USR-TU_ACCESS_TOKEN_AQUI');

// PedidosYa
define('PEYA_HABILITADO', false);
define('PEYA_CLIENT_ID', '');
define('PEYA_CLIENT_SECRET', '');
define('PEYA_STORE_ID', '');

// ARCA / AFIP
define('AFIP_CUIT', '20345678901');
define('AFIP_PUNTO_VENTA', 1);
define('AFIP_PRODUCCION', false);