# GUÍA TÉCNICA DE INTEGRACIÓN Y CONFIGURACIÓN DE APIS
## Hermosos Perdedores Cerveteca - ERP Omnicanal Multisede

---

### 1. FACTURACIÓN ELECTRÓNICA ARCA / AFIP (WSFE v1)

El sistema ya incluye el motor oficial de facturación electrónica compatible con la nueva Agencia de Recaudación y Control Aduanero (ARCA, ex AFIP), conforme a la Resolución General AFIP 4892 (Códigos QR fiscales interoperables con CAE).

#### Modo de Operación Actual
* **Simulación / Homologación Activa:** El sistema autoriza y genera automáticamente el número de CAE, fecha de vencimiento y código QR interoperable oficial de AFIP en cada venta del POS o pedido web, permitiendo imprimir Facturas B, Facturas C y Remitos sin requerir certificados de producción inmediatos.

#### Pasos para pasar a Modo Producción Fiscal con tu CUIT:
1. **Generar Clave Privada y CSR (Certificado):**
   En tu terminal o servidor:
   ```bash
   openssl genrsa -out privada.key 2048
   openssl req -new -key privada.key -subj "/C=AR/O=Hermosos Perdedores/CN=HermososPerdedores/serialNumber=CUIT 20345678901" -out pedido.csr
   ```
2. **Subir CSR a la web de AFIP:**
   * Ingresa a [afip.gob.ar](https://www.afip.gob.ar) con tu CUIT y Clave Fiscal Nivel 3.
   * Ve a **Administración de Certificados Digitales** y sube el archivo `pedido.csr`.
   * Descarga el certificado generado como `certificado.crt`.
3. **Delegar el Servicio WSFE:**
   * En **Administrador de Relaciones de Clave Fiscal**, agrega el servicio:
     `Web Services > Facturación Electrónica - WSFE v1`.
4. **Configurar en `config.php`:**
   * Sube `privada.key` y `certificado.crt` a la carpeta protegida de tu hosting.
   * En `config.php`, ajusta:
     ```php
     define('AFIP_CUIT', '20345678901'); // Tu CUIT sin guiones
     define('AFIP_PUNTO_VENTA_RAMOS', 1); // Punto de venta asignado en AFIP para Ramos Mejía
     define('AFIP_PUNTO_VENTA_HAEDO', 2); // Punto de venta asignado en AFIP para Haedo
     define('AFIP_PRODUCCION', true); // Cambiar a true para autorizar contra servidores oficiales
     ```
5. **Emisión y Consulta:**
   * Endpoint de emisión: `POST /api/factura_arca.php`
   * Consulta de último comprobante: `GET /api/factura_arca.php?punto_venta=1&tipo=FACTURA_B`

---

### 2. IMPRESIÓN DE TICKETS, FACTURAS Y REMITOS

El sistema cuenta con un motor de impresión directo mediante CSS Print y soporte para impresoras térmicas de 80mm y 58mm (Epson TM-T20, Hasar, Xprinter, Bematech) y formato estándar A4.

#### Configuración de la Impresora en Mostrador:
1. En Windows / Mac, ve a la configuración de impresoras y selecciona tu impresora térmica como predeterminada o crea un perfil de impresión con:
   * **Tamaño de papel:** Roll Paper 80 x 297 mm (o 58mm).
   * **Márgenes:** Ninguno (0 mm).
   * **Gráficos de fondo:** Activado (para imprimir el código QR y logos con nitidez).
2. **Impresión con un clic:** Al finalizar una venta en `pos.html` o desde el ERP (`admin/index.html`), presiona **"Imprimir Factura Fiscal"** o **"Imprimir Remito / Despacho"**: se abrirá instantáneamente la vista de ticket térmico formateada y lista para imprimir o cortar.

---

### 3. INTEGRACIÓN CON PEDIDOSYA

Hermosos Perdedores cuenta con su tienda oficial en PedidosYa:
`https://www.pedidosya.com.ar/restaurantes/la-matanza/ph-cervezas-heladas-8d632941-4f25-48cf-853f-f1675c29009a-menu`

#### Webhook de Pedidos Entrantes:
Cada vez que un cliente realiza una compra por PedidosYa, la plataforma envía una notificación webhook a tu servidor:
* **Webhook Local Ramos Mejía:** `https://perdedoreshermosos.com.ar/api/pedidosya.php?sucursal_id=1`
* **Webhook Local Haedo:** `https://perdedoreshermosos.com.ar/api/pedidosya.php?sucursal_id=2`

#### Acciones automáticas ejecutadas por el backend:
1. Identifica la sucursal emisora y bloquea pesimistamente el stock (`FOR UPDATE`).
2. Descuenta automáticamente las latas y botellas vendidas de la tabla `inventarios` del local correspondiente y de `productos.stock_actual`.
3. Registra la orden en `pedidos` con canal `PEDIDOSYA_RAMOS` o `PEDIDOSYA_HAEDO` con estado `EN_PREPARACION` para empaque y entrega al rider.
4. Asienta la trazabilidad en `movimientos_stock` con la referencia oficial de PedidosYa.

---

### 4. IMPORTADOR DE LISTAS DE PRECIOS Y FACTURAS DE COMPRA DE PROVEEDORES

Ubicado en el Panel ERP (`admin/index.html` > pestaña **"Proveedores & Compras"**):
* **Archivo admitido:** `.csv` o `.xlsx` delimitado por comas o punto y coma.
* **Columnas reconocidas automáticamente:** `Codigo`, `Descripcion`, `Costo`, `Venta` (opcional), `Cantidad_Ingresada`.
* **Tratamiento contable y financiero simultáneo:**
  1. **Stock:** Aumenta las existencias en la sucursal seleccionada (Ramos Mejía o Haedo).
  2. **Catálogo:** Actualiza precios de compra y venta.
  3. **Caja / Banco:** Registra la salida de dinero según la condición elegida (Efectivo de Caja, Transferencia Bancaria o Cuenta Corriente).
  4. **Documento Fiscal:** Almacena la Factura A/B/C del proveedor con discriminación del 21% de crédito fiscal IVA para la liquidación mensual.

---

### 5. MERCADO PAGO CHECKOUT PRO & POINT

* Endpoint de preferencia: `POST /api/mercadopago_crear_preferencia.php`
* En `config.php`, reemplaza `MP_ACCESS_TOKEN` con tu Access Token de producción obtenido en [mercadopago.com.ar/developers](https://www.mercadopago.com.ar/developers).
* El sistema ya soporta retorno automático (`?pago=exito`) y descuento automático de stock antes del redireccionamiento para evitar ventas duplicadas.
